# Compilador
Compilador utilizando análise sintática descendente não recursivo

## Como executar
Coloque o codigo fonte no arquivo main.txt e 
Na Pasta raiz digite 
```
python src/comp.py > output.txt
```
